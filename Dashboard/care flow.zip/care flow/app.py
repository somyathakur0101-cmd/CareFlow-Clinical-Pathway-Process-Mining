
import streamlit as st
import pandas as pd
import plotly.express as px
import os
import glob

# ==========================================
# 1. PAGE CONFIGURATION
# ==========================================

st.set_page_config(
    page_title="CareFlow Dashboard",
    page_icon="🏥",
    layout="wide"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
VIS_DIR = os.path.join(BASE_DIR, "visualizations")

st.title("🏥 CareFlow: Clinical Pathway Process Mining")
st.markdown(
    "Interactive Hospital OPD Data Analytics Dashboard"
)
st.markdown("---")


# ==========================================
# 2. LOAD EXCEL DATASET
# ==========================================

# Automatically find the Excel file in data folder

expected_file = os.path.join(
    DATA_DIR,
    "HospitalOPD_CareFlow_cleaned_v4.xlsx"
)

if os.path.exists(expected_file):
    DATA_PATH = expected_file
else:
    excel_files = glob.glob(os.path.join(DATA_DIR, "*.xlsx"))
    excel_files = [
        f for f in excel_files
        if not os.path.basename(f).startswith("~$")
    ]
    DATA_PATH = excel_files[0] if excel_files else None


@st.cache_data
def load_data(file_path):

    data = pd.read_excel(
        file_path,
        sheet_name="Cleaned_Data"
    )

    data["appointment_start_datetime"] = pd.to_datetime(
        data["appointment_start_datetime"],
        errors="coerce"
    )

    data["appointment_month"] = (
        data["appointment_start_datetime"]
        .dt.to_period("M")
        .astype(str)
    )

    return data


if DATA_PATH is None:

    st.error("Excel dataset not found inside the data folder.")

    st.info(
        "Please place HospitalOPD_CareFlow_cleaned_v4.xlsx "
        "inside the data folder."
    )

    st.stop()


try:
    df = load_data(DATA_PATH)

except Exception as e:

    st.error(f"Dataset loading error: {e}")
    st.stop()


# ==========================================
# 3. SIDEBAR FILTERS
# ==========================================

st.sidebar.title("🎛️ Dashboard Filters")
try:
    df = load_data(DATA_PATH)

except Exception as e:
    st.error(f"Dataset loading error: {e}")
    st.stop()
filtered_df = df.copy()

# Date filter

valid_dates = df["appointment_start_datetime"].dropna()

if not valid_dates.empty:

    min_date = valid_dates.min().date()
    max_date = valid_dates.max().date()

    selected_dates = st.sidebar.date_input(
        "Appointment Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )

    if isinstance(selected_dates, (tuple, list)) and len(selected_dates) == 2:

        start_date, end_date = selected_dates

        filtered_df = filtered_df[
            filtered_df["appointment_start_datetime"].dt.date.between(
                start_date, end_date
            )
        ]


# Doctor filter

doctors = sorted(
    df["prescription_doctor_name"]
    .dropna()
    .astype(str)
    .unique()
    .tolist()
)

selected_doctor = st.sidebar.selectbox(
    "Select Doctor",
    ["All"] + doctors
)

if selected_doctor != "All":

    filtered_df = filtered_df[
        filtered_df["prescription_doctor_name"].astype(str)
        == selected_doctor
    ]


# Patient flow filter

flows = sorted(
    df["flow_name"]
    .dropna()
    .astype(str)
    .unique()
    .tolist()
)

selected_flow = st.sidebar.selectbox(
    "Select Patient Flow",
    ["All"] + flows
)

if selected_flow != "All":

    filtered_df = filtered_df[
        filtered_df["flow_name"].astype(str)
        == selected_flow
    ]


# ==========================================
# 4. PROJECT OVERVIEW / KPI CARDS
# ==========================================

st.header("📊 Project Overview")

total_records = len(filtered_df)

total_patients = filtered_df["patient_id"].nunique()

total_appointments = filtered_df["appointment_id"].nunique()

total_prescriptions = filtered_df["prescription_order_id"].nunique()

total_lab_tests = filtered_df["lab_id"].nunique()

total_imaging = filtered_df["imaging_request_id"].nunique()

total_medicines = filtered_df["medicine_name"].nunique()


col1, col2, col3 = st.columns(3)

col1.metric("Total Records", f"{total_records:,}")
col2.metric("Total Patients", f"{total_patients:,}")
col3.metric("Total Appointments", f"{total_appointments:,}")


col4, col5, col6 = st.columns(3)

col4.metric("Prescription Orders", f"{total_prescriptions:,}")
col5.metric("Lab Tests", f"{total_lab_tests:,}")
col6.metric("Imaging Requests", f"{total_imaging:,}")


st.caption(
    f"Unique medicines in selected data: {total_medicines:,}"
)

st.markdown("---")


# ==========================================
# 5. DASHBOARD TABS
# ==========================================

tabs = st.tabs([
    "Overview",
    "Patient Analysis",
    "Prescription Analysis",
    "Lab & Imaging",
    "Pharmacy",
    "Data Quality",
    "Dataset Preview"
])


# ==========================================
# TAB 1: OVERVIEW
# ==========================================

with tabs[0]:

    st.subheader("Hospital Activity Overview")

    col1, col2 = st.columns(2)

    with col1:

        flow_data = (
            filtered_df["flow_name"]
            .fillna("Unknown")
            .value_counts()
            .reset_index()
        )

        flow_data.columns = ["Patient Flow", "Records"]

        fig = px.pie(
            flow_data,
            names="Patient Flow",
            values="Records",
            hole=0.4,
            title="Clinical Flow Distribution"
        )

        st.plotly_chart(fig, use_container_width=True)

    with col2:

        monthly_data = (
            filtered_df.dropna(
                subset=["appointment_start_datetime"]
            )
            .groupby("appointment_month")
            .size()
            .reset_index(name="Records")
            .sort_values("appointment_month")
        )

        if not monthly_data.empty:

            fig = px.line(
                monthly_data,
                x="appointment_month",
                y="Records",
                markers=True,
                title="Monthly Hospital Activity"
            )

            st.plotly_chart(fig, use_container_width=True)

        else:
            st.info("No appointment date data available.")

    st.markdown("---")

    st.subheader("Existing Project Visualizations")

    image_files = [
        ("Monthly Trends", "monthly_trends.png"),
        ("Doctor Analysis", "doctor_analysis.png"),
        ("Medicine Distribution", "medicine_distribution.png"),
        ("Data Quality", "data_quality.png")
    ]

    for i in range(0, len(image_files), 2):

        cols = st.columns(2)

        for j, col in enumerate(cols):

            index = i + j

            if index < len(image_files):

                image_title, image_name = image_files[index]

                image_path = os.path.join(
                    VIS_DIR,
                    image_name
                )

                with col:

                    st.write(f"**{image_title}**")

                    if os.path.exists(image_path):

                        st.image(
                            image_path,
                            use_container_width=True
                        )

                    else:

                        st.warning(
                            f"{image_name} not found."
                        )


# ==========================================
# TAB 2: PATIENT ANALYSIS
# ==========================================

with tabs[1]:

    st.subheader("Patient and Appointment Analysis")

    patient_data = (
        filtered_df.groupby("patient_id")["appointment_id"]
        .nunique()
        .reset_index(name="Appointments")
        .sort_values("Appointments", ascending=False)
        .head(10)
    )

    if not patient_data.empty:

        fig = px.bar(
            patient_data,
            x="patient_id",
            y="Appointments",
            title="Top 10 Patients by Appointments",
            labels={
                "patient_id": "Patient ID",
                "Appointments": "Appointments"
            }
        )

        st.plotly_chart(fig, use_container_width=True)

    monthly_patients = (
        filtered_df.dropna(
            subset=["appointment_start_datetime"]
        )
        .groupby("appointment_month")["patient_id"]
        .nunique()
        .reset_index(name="Patients")
        .sort_values("appointment_month")
    )

    if not monthly_patients.empty:

        fig = px.line(
            monthly_patients,
            x="appointment_month",
            y="Patients",
            markers=True,
            title="Monthly Unique Patients"
        )

        st.plotly_chart(fig, use_container_width=True)


# ==========================================
# TAB 3: PRESCRIPTION ANALYSIS
# ==========================================

with tabs[2]:

    st.subheader("Prescription and Doctor Analysis")

    col1, col2 = st.columns(2)

    with col1:

        doctor_data = (
            filtered_df.dropna(
                subset=["prescription_doctor_name"]
            )
            .groupby("prescription_doctor_name")
            ["prescription_order_id"]
            .nunique()
            .reset_index(name="Prescription Orders")
            .sort_values(
                "Prescription Orders",
                ascending=False
            )
            .head(10)
        )

        if not doctor_data.empty:

            fig = px.bar(
                doctor_data,
                x="prescription_doctor_name",
                y="Prescription Orders",
                title="Top 10 Doctors by Prescription Orders"
            )

            st.plotly_chart(fig, use_container_width=True)

    with col2:

        medicine_data = (
            filtered_df.dropna(
                subset=["medicine_name"]
            )
            .groupby("medicine_name")
            .size()
            .reset_index(name="Records")
            .sort_values("Records", ascending=False)
            .head(10)
        )

        if not medicine_data.empty:

            fig = px.bar(
                medicine_data,
                x="medicine_name",
                y="Records",
                title="Top 10 Prescribed Medicines"
            )

            st.plotly_chart(fig, use_container_width=True)

        else:
            st.info("No medicine records available.")

    st.markdown("---")

    col1, col2 = st.columns(2)

    col1.metric(
        "Unique Prescription Orders",
        filtered_df["prescription_order_id"].nunique()
    )

    col2.metric(
        "Unique Doctors",
        filtered_df["prescription_doctor_name"].nunique()
    )


# ==========================================
# TAB 4: LAB AND IMAGING ANALYSIS
# ==========================================

with tabs[3]:

    st.subheader("Laboratory and Imaging Analysis")

    col1, col2 = st.columns(2)

    with col1:

        lab_data = (
            filtered_df.dropna(subset=["lab_name"])
            .groupby("lab_name")
            .size()
            .reset_index(name="Tests")
            .sort_values("Tests", ascending=False)
            .head(10)
        )

        if not lab_data.empty:

            fig = px.bar(
                lab_data,
                x="lab_name",
                y="Tests",
                title="Top 10 Laboratory Tests"
            )

            st.plotly_chart(fig, use_container_width=True)

        else:

            st.info("No laboratory records available.")

    with col2:

        imaging_data = (
            filtered_df.dropna(subset=["imaging_name"])
            .groupby("imaging_name")
            .size()
            .reset_index(name="Requests")
            .sort_values("Requests", ascending=False)
            .head(10)
        )

        if not imaging_data.empty:

            fig = px.bar(
                imaging_data,
                x="imaging_name",
                y="Requests",
                title="Imaging Request Distribution"
            )

            st.plotly_chart(fig, use_container_width=True)

        else:

            st.info("No imaging records available.")

    col1, col2 = st.columns(2)

    col1.metric(
        "Unique Lab IDs",
        filtered_df["lab_id"].nunique()
    )

    col2.metric(
        "Unique Imaging Requests",
        filtered_df["imaging_request_id"].nunique()
    )


# ==========================================
# TAB 5: PHARMACY ANALYSIS
# ==========================================

with tabs[4]:

    st.subheader("Pharmacy and Medicine Analysis")

    pharmacy_data = (
        filtered_df.dropna(subset=["medicine_name"])
        .groupby("medicine_name")
        .size()
        .reset_index(name="Records")
        .sort_values("Records", ascending=False)
        .head(15)
    )

    if not pharmacy_data.empty:

        fig = px.bar(
            pharmacy_data,
            x="medicine_name",
            y="Records",
            title="Top 15 Medicines in Pharmacy Records"
        )

        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(
            pharmacy_data,
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info(
            "No pharmacy records available for selected filters."
        )


# ==========================================
# TAB 6: DATA QUALITY ANALYSIS
# ==========================================

with tabs[5]:

    st.subheader("Data Quality and Cleaning Analysis")

    missing_data = (
        filtered_df.isnull()
        .sum()
        .reset_index()
    )

    missing_data.columns = [
        "Column",
        "Missing Values"
    ]

    missing_data = (
        missing_data[
            missing_data["Missing Values"] > 0
        ]
        .sort_values(
            "Missing Values",
            ascending=False
        )
    )

    col1, col2 = st.columns(2)

    col1.metric(
        "Total Missing Cells",
        f"{int(filtered_df.isnull().sum().sum()):,}"
    )

    col2.metric(
        "Columns with Missing Values",
        len(missing_data)
    )

    if not missing_data.empty:

        fig = px.bar(
            missing_data.head(15),
            x="Column",
            y="Missing Values",
            title="Top 15 Columns with Missing Values"
        )

        st.plotly_chart(fig, use_container_width=True)

    else:

        st.success("No missing values found.")

    st.markdown("---")

    st.subheader("Data Cleaning Flags")

    flag_columns = [
        "flag_possible_duplicate_extra",
        "flag_lab_id_reused",
        "flag_imaging_id_reused",
        "flag_admin_doctor",
        "flag_prescription_end_before_start",
        "flag_prescription_start_missing",
        "flag_event_before_appointment"
    ]

    available_flags = [
        c for c in flag_columns
        if c in filtered_df.columns
    ]

    if available_flags:

        flag_summary = pd.DataFrame({
            "Quality Check": available_flags,
            "Flagged Records": [
                int(
                    filtered_df[c].fillna(False).astype(bool).sum()
                )
                for c in available_flags
            ]
        })

        st.dataframe(
            flag_summary,
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info("No cleaning flags found.")

    st.subheader("Missing Value Details")

    st.dataframe(
        missing_data,
        use_container_width=True,
        hide_index=True
    )


# ==========================================
# TAB 7: DATASET PREVIEW
# ==========================================

with tabs[6]:

    st.subheader("Cleaned Dataset Preview")

    st.write(
        f"Showing {min(500, len(filtered_df)):,} records "
        f"out of {len(filtered_df):,} filtered records."
    )

    st.dataframe(
        filtered_df.head(500),
        use_container_width=True,
        height=450
    )

    csv_data = filtered_df.to_csv(
        index=False
    ).encode("utf-8")

    st.download_button(
        label="⬇️ Download Filtered Dataset",
        data=csv_data,
        file_name="CareFlow_Filtered_Data.csv",
        mime="text/csv"
    )


# ==========================================
# 6. FOOTER
# ==========================================

st.markdown("---")

st.markdown(
    """
    **CareFlow: Clinical Pathway Process Mining**

    Hospital OPD Data Analytics Project

    Developed using Python, Pandas, Plotly and Streamlit.
    """
)
